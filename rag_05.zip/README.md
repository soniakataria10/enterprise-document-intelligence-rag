# Local Enterprise PDF RAG System

A Local Retrieval-Augmented Generation (RAG) application built with Python, LangChain, Streamlit, ChromaDB, Hugging Face embeddings, and Llama 3.2, BM25 hybrid retrieval, a CrossEncoder reranker, Ollama, Streamlit, basic access control, logging, and evaluation.

The application allows users to upload PDF documents into a local Knowledge Base and ask natural-language questions about their content.

The entire system runs locally without requiring an Azure subscription or cloud infrastructure.

## Requirements
- Python 3.11 or 3.12 recommended
- Ollama installed and running
- `ollama pull llama3.2`

## Setup (Windows PowerShell)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```
## Run
```powershell
streamlit run app.py
```

## Evaluate
Edit `evaluation_data/questions.json`, then:
```powershell
python evaluate.py
```

# Local Enterprise PDF RAG System

A local **Retrieval-Augmented Generation (RAG)** application built with Python, LangChain, Streamlit, ChromaDB, Hugging Face embeddings, and Llama 3.2, BM25 hybrid retrieval, a CrossEncoder reranker, Ollama, Streamlit, basic access control, logging, and evaluation.

The application allows users to upload PDF documents into a local Knowledge Base and ask natural-language questions about their content.

The entire system runs locally without requiring an Azure subscription or cloud infrastructure.

---

## Features

### PDF Knowledge Base

* Upload one or multiple PDF documents.
* PDF-only document ingestion.
* Automatically extract text from PDFs.
* Split documents into smaller chunks.
* Generate vector embeddings.
* Store embeddings locally in ChromaDB.
* View the number of documents and chunks in the Knowledge Base.

### Incremental Document Ingestion

New documents can be added without rebuilding the entire vector database.

New PDF
   ↓
Check if document already exists
   ↓
New?
 ┌─┴─┐
Yes  No
 ↓    ↓
Index Skip

Only newly uploaded documents are processed.

### Duplicate Prevention

The system uses the PDF filename to determine whether a document already exists.
No duplicate chunks are added to ChromaDB.

### Document Deletion

Documents can be deleted from the Knowledge Base using a confirmation dialog.

Deleting a document removes:

1. The PDF file from the local document directory.
2. All corresponding chunks from ChromaDB.

### Local LLM

The project uses **Llama 3.2** locally, allowing the application to generate answers without depending on a cloud LLM API.

# Architecture

                         ┌──────────────────┐
                         │     Streamlit    │
                         │       UI         │
                         └────────┬─────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │                           │
                    ▼                           ▼
             Knowledge Base               Question
                    │                           │
                    ▼                           ▼
             PDF Documents                Embedding
                    │                           │
                    ▼                           ▼
              PyMuPDFLoader               ChromaDB
                    │                           │
                    ▼                           ▼
               Text Chunks              Vector Search
                    │                           │
                    ▼                           ▼
        Hugging Face Embeddings          Retrieved Chunks
                    │                           │
                    ▼                           ▼
                ChromaDB                   Reranking
                                                │
                                                ▼
                                         Relevant Context
                                                │
                                                ▼
                                           Llama 3.2
                                                │
                                                ▼
                                             Answer

# Technologies Used

| Technology            | Purpose                 |
| --------------------- | ----------------------- |
| Python                | Application development |
| Streamlit             | Web UI                  |
| LangChain             | RAG orchestration       |
| ChromaDB              | Vector database         |
| Hugging Face          | Text embeddings         |
| Sentence Transformers | Embedding model         |
| Llama 3.2             | Local LLM               |
| PyMuPDF               | PDF text extraction     |

---

# Installation

## 1. Clone the repository

git clone <your-repository-url>
cd final_local_enterprise_rag

## 2. Create a virtual environment

python -m venv .venv
Activate it:
.\.venv\Scripts\activate

## 3. Install dependencies

pip install -r requirements.txt

# Install and Configure Llama 3.2

This project uses Llama 3.2 as the local LLM.
Make sure your local LLM runtime is installed and that the required Llama 3.2 model is available.
Verify the model before running the application.

Example:
ollama list

# Run the Application

Activate the virtual environment:

.\.venv\Scripts\activate

Start Streamlit:

streamlit run app.py

The application will open in your browser.

# Example Questions

After uploading company policy documents, users can ask questions such as:


---

# Hallucination Control

The RAG system is designed to reduce hallucinations by instructing the LLM to answer only from the retrieved document context.
If sufficient information is not available, the system returns:

I couldn't find the answer in the provided documents.

# RAG Testing

The system should be tested using several categories of questions.

### Basic retrieval questions
    What is Cineplex's Code of Business Conduct and Ethics? 
    What are the main principles outlined in Cineplex's Code of Business Conduct and Ethics? 
    What does Cineplex's Diversity and Inclusion Policy state? 
    What does Cineplex's Human Rights Policy cover? 
    What does Cineplex's Health and Safety Policy cover? 
    What is Cineplex's Harassment, Discrimination and Workplace Violence Policy? 
    What is the purpose of Cineplex's Confidential Information Policy? 
    What is Cineplex's Disclosure Policy? 
    What is Cineplex's Insider Trading Policy? 
    What does Cineplex's Supplier Code of Conduct require? 
### Specific fact questions
    What does Cineplex's policy say about conflicts of interest? 
    What should an employee do if they have a potential conflict of interest? 
    What does Cineplex's Code of Conduct say about confidential information? 
    What types of conduct are prohibited under Cineplex's harassment policy? 
    How does Cineplex define workplace harassment? 
    What does Cineplex's Human Rights Policy say about discrimination? 
    What responsibilities do employees have regarding workplace health and safety? 
    What responsibilities do managers have under the workplace policies? 
    What does Cineplex's policy say about violence in the workplace? 
    What does the Supplier Code of Conduct require from suppliers? 
### Multi-document questions 
    How do Cineplex's Human Rights Policy and Diversity and Inclusion Policy relate to each other? 
    What similarities exist between the Code of Business Conduct and the Human Rights Policy? 
    How do the Harassment Policy and Human Rights Policy address inappropriate workplace behaviour? 
    Compare Cineplex's Health and Safety Policy with its Workplace Violence provisions. 
    How do the Code of Business Conduct and Confidential Information Policy address employee responsibilities? 
    What relationship exists between the Code of Conduct and the Conflict of Interest requirements? 
    Compare the responsibilities of employees under the Code of Conduct and the Supplier Code of Conduct. 
    How do Cineplex's governance policies support ethical business conduct? 
    What policies would be relevant to an employee who believes they are experiencing discrimination? 
    Which Cineplex policies would potentially apply to a situation involving both harassment and discrimination? 
### Scenario-based questions 
    An employee believes their manager is treating them differently because of a protected characteristic. Which Cineplex policies could apply, and why? 
    An employee receives confidential company information and wants to share it with someone outside the company. What policies should they consider? 
    An employee discovers that they have a personal relationship with a supplier involved in a business decision. What should they do according to the relevant policies? 
    An employee witnesses inappropriate behaviour in the workplace but is not personally involved. What policies might apply? 
    A supplier violates one of Cineplex's ethical requirements. What document should management consult? 
    An employee believes a workplace incident creates a health and safety risk. Which policy is relevant and what responsibilities does it describe? 
    An employee receives information that could potentially be considered material non-public information. Which Cineplex policy should they consult? 
    An employee is concerned about discrimination and harassment at the same time. Which policies should they review? 
### Conversational / follow-up questions 
    Start with:
    What does Cineplex's Human Rights Policy say about discrimination?
    Then ask:
    What about harassment?
    Then:
    Who does that policy apply to?
    Then:
    What responsibilities do employees have under it?
    Then:
    Which other Cineplex policy is related to this?
    Then:
    How are the two policies different?
### 'Answer Not Found' questions
What is the population of Canada?

Expected response:

I couldn't find the answer in the provided documents.

